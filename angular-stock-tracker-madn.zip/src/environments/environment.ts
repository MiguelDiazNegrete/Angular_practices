export const environment = {
  apiKey: 'bu4f8kn48v6uehqi3cqg' // Finnhub API key
}
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { map, Observable, tap } from 'rxjs';
import { Sentiment } from '../models/sentiment.model';
import { Stock } from '../models/stock.model';
import { FinnhubService } from '../services/finnhub-api.service';
import { StockService } from '../services/stock.service';

@Component({
  selector: 'app-sentiment',
  templateUrl: './sentiment.component.html',
})
export class SentimentComponent implements OnInit {
  public isBusy: boolean = false;
  public symbol: string;
  public stock: Stock;
  public sentiments: Observable<any>;
  public dates: { month: number; year: number }[] = [];

  constructor(
    private route: ActivatedRoute,
    private stockService: StockService,
    private finnhubService: FinnhubService
  ) {}

  ngOnInit(): void {
    this.isBusy = true;
    this.stockService.getStocks();

    this.symbol = this.route.snapshot.params['symbol'];
    this.stock = this.stockService.getStockBySymbol(this.symbol);

    const { from, to } = this.getStringDates();

    this.dates = this.getPreviousDates();
    this.sentiments = this.finnhubService
      .getSentiment(this.symbol, { from, to })
      .pipe(
        map((response: { symbol: string; data: Sentiment[] }) =>
          response.data.filter((s: Sentiment) =>
            this.dates.some(
              (m: { month: number; year: number }) => m.month === s?.month
            )
          )
        ),
        map((response: Sentiment[]) => {
          // fill where no data available
          while (response.length < 3) {
            response.push(null);
          }
          return response;
        }),
        tap((data: Sentiment[]) => {
          this.isBusy = false;
        })
      );
  }

  // get 3 months before with year, excluding current month
  private getPreviousDates(): { month: number; year: number }[] {
    const d: Date = new Date();
    d.setMonth(d.getMonth() - 3);

    const dates: { month: number; year: number }[] = [];
    for (let i = 0; i < 3; i++) {
      dates.push({
        month: d.getMonth() + 1,
        year: d.getFullYear(),
      });
      d.setMonth(d.getMonth() + 1);
    }
    return dates;
  }

  private getStringDates(): { from: string; to: string } {
    const d: Date = new Date();
    d.setMonth(d.getMonth() - 1);

    let month: string = this.convertTwoDigits(d.getMonth() + 1);
    let day: string = this.convertTwoDigits(d.getDate());
    const to: string = `${d.getFullYear()}-${month}-${day}`;

    d.setMonth(d.getMonth() - 3);
    month = this.convertTwoDigits(d.getMonth() + 1);
    day = this.convertTwoDigits(d.getDate());
    const from: string = `${d.getFullYear()}-${month}-${day}`;

    return { from, to };
  }

  private convertTwoDigits(num: number): string {
    return num < 10 ? '0' + num : '' + num;
  }
}

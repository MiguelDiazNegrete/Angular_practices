import { Component, OnDestroy, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { forkJoin, Observable, Subscription } from 'rxjs';
import { Stock } from '../models/stock.model';
import { FinnhubService } from '../services/finnhub-api.service';
import { StockService } from '../services/stock.service';

@Component({
  selector: 'app-stock-tracker',
  templateUrl: './stock-tracker.component.html',
})
export class StockTrackerComponent implements OnDestroy {
  @ViewChild('trackForm', { static: true }) trackForm: NgForm;

  subscription: Subscription;
  isBusy: boolean = false;

  message: string = null;

  constructor(
    private finnhubService: FinnhubService,
    private stockService: StockService
  ) {}

  submit(): void {
    const stockInput: string = (<string>this.trackForm.value.stockInput).trim();

    if (this.stockService.getStockBySymbol(stockInput) != null) {
      this.displayTemporalMessage(
        `Stock <b>${stockInput}</b> is already tracked!`
      );
      return;
    }

    this.isBusy = true;
    const sources: Observable<any>[] = [
      this.finnhubService.getStock(stockInput),
      this.finnhubService.getCompany(stockInput),
    ];

    this.subscription = forkJoin(sources).subscribe(
      ([stockData, companyData]) => {
        // didn't find info, then don't save
        if (!stockData.dp || stockData.dp === 0) {
          this.displayTemporalMessage(
            `NO data was found for <b>${stockInput}</b>!`
          );
          this.isBusy = false;
          return;
        }
        const newStock: Stock = {
          companyName: companyData.result[0].description,
          symbol: companyData.result[0].symbol,
          changeToday: stockData.dp,
          openingPrice: stockData.o,
          currentPrice: stockData.c,
          highPrice: stockData.h,
        };
        this.stockService.addStock(newStock);
        this.isBusy = false;
        this.trackForm.control.get('stockInput').setValue(null);
      }
    );
  }

  displayTemporalMessage(message: string, timer: number = 4000) {
    this.message = message;
    setTimeout(() => {
      this.message = null;
    }, timer);
  }

  ngOnDestroy(): void {
    if (this.subscription != null) this.subscription.unsubscribe();
  }
}

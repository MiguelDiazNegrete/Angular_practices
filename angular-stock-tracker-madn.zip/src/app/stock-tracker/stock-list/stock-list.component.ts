import { Component, OnInit } from '@angular/core';
import { Stock } from '../../models/stock.model';
import { StockService } from '../../services/stock.service';
import { StorageService } from '../../services/storage.service';

@Component({
  selector: 'app-stock-list',
  templateUrl: './stock-list.component.html',
  styleUrls: ['./stock-list.component.css'],
})
export class StockListComponent implements OnInit {
  stocks: Stock[];

  constructor(private stockService: StockService) {}

  ngOnInit() {
    this.stocks = this.stockService.getStocks();
    this.stockService.onStocksChange.subscribe({
      next: (stocks: Stock[]) => {
        this.stocks = stocks;
      },
      error: (error: any) => {
        console.error(error);
      },
    });
  }

  removeStock(symbol: string) {
    this.stockService.deleteStock(symbol);
  }
}

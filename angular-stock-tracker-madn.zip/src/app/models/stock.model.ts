export class Stock {
  constructor(json?: Stock | any) {
    if (json) Object.assign(this, json);
  }
  symbol: string;
  companyName: string;
  changeToday: number; // percentage
  openingPrice: number;
  currentPrice: number;
  highPrice: number;
}

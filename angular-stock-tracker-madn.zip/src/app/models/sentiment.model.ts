export class Sentiment {
  constructor(json?: Sentiment | any) {
    if (json) Object.assign(this, json);
  }
  change: number;
  month: number;
  mspr: number;
  symbol: string;
  year: number;
}

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
@Injectable({ providedIn: 'root' })
export class FinnhubService {
  get token() {
    return environment.apiKey;
  }

  get quoteUrl() {
    return 'https://finnhub.io/api/v1/quote';
  }
  get searchUrl() {
    return 'https://finnhub.io/api/v1/search';
  }
  get sentimentUrl() {
    return 'https://finnhub.io/api/v1/stock/insider-sentiment';
  }

  constructor(private http: HttpClient) {}

  public getStock(value: string): Observable<any> {
    const url = `${this.quoteUrl}?symbol=${value}&token=${this.token}`;
    return this.http.get(url);
  }

  public getCompany(value: string): Observable<any> {
    const url = `${this.searchUrl}?q=${value}&token=${this.token}`;
    return this.http.get(url);
  }

  public getSentiment(
    symbol: string,
    dates: { from: string; to: string }
  ): Observable<any> {
    const url = `${this.sentimentUrl}?symbol=${symbol}&from=${dates.from}&to=${dates.to}&token=${this.token}`;
    return this.http.get(url);
  }
}

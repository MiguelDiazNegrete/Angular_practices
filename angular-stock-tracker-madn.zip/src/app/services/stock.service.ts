import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { Stock } from '../models/stock.model';
import { StorageService } from './storage.service';

@Injectable({ providedIn: 'root' })
export class StockService {
  public onStocksChange: Subject<Stock[]> = new Subject<Stock[]>();
  public stocks: Stock[] = [];

  constructor(private storageService: StorageService) {}

  getStocks(): Stock[] | null {
    const stocksFromStorage: Stock[] = this.storageService.loadFromStorage();
    if (stocksFromStorage != null) {
      this.stocks = stocksFromStorage;
    }
    return this.stocks?.slice();
  }

  getStockBySymbol(symbol: string): Stock {
    return this.stocks.find((st) => st.symbol === symbol);
  }

  addStock(newStock: Stock): string {
    this.stocks.push(newStock);
    this.storageService.saveItem(newStock.symbol, JSON.stringify(newStock));
    this.onStocksChange.next(this.stocks.slice());
    return newStock.symbol;
  }

  deleteStock(symbol: string): Stock {
    const index: number = this.stocks.findIndex((st) => st.symbol === symbol);
    if (index !== -1) {
      this.storageService.deleteItem(symbol);
      const deletedStock: Stock = this.stocks.splice(index, 1)[0];
      this.onStocksChange.next(this.stocks?.slice());
      return deletedStock;
    }
    return null;
  }
}

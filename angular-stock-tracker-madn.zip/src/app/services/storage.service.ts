import { Injectable } from '@angular/core';
import { Stock } from '../models/stock.model';

@Injectable({ providedIn: 'root' })
export class StorageService {
  // keys of stackblitz it seems
  private keysExceptions: string[] = [
    'editorHasEmittedBundle',
    'editorLastConnected',
  ];
  private stocksLoaded = false;

  private loadKeys(): string[] | null {
    let keys: string[] = [];
    for (let i: number = 0; i < 30; i++) {
      const key: string = localStorage.key(i);
      const foundExeption: boolean = this.keysExceptions.some((k) => k === key);
      if (!foundExeption && key) {
        keys.push(key);
      }
    }

    if (keys.length > 0) return keys;
    return null;
  }

  public loadFromStorage(): Stock[] | null {
    if (!this.stocksLoaded) {
      let keys: string[] = this.loadKeys();
      const stocks: Stock[] = [];
      for (let i: number = 0; i < keys?.length; i++) {
        const json: string = this.getItem(keys[i]);
        const stock: Stock = new Stock(JSON.parse(json));
        stocks.push(stock);
      }
      this.stocksLoaded = true;
      if (stocks.length > 0) return stocks;
    }
    return null;
  }

  public saveItem(key: string, value: string): void {
    localStorage.setItem(key, value);
  }

  public getItem(key: string): string {
    return localStorage.getItem(key);
  }

  public deleteItem(key: string): void {
    localStorage.removeItem(key);
  }
}

import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { SentimentComponent } from './sentiment/sentiment.component';
import { StockTrackerComponent } from './stock-tracker/stock-tracker.component';
import { StockListComponent } from './stock-tracker/stock-list/stock-list.component';
import { PercentHighilightDirective } from './directives/percent-highlight.directive';
import { MonthStringPipe } from './pipes/month-string.pipe';

@NgModule({
  imports: [BrowserModule, FormsModule, AppRoutingModule, HttpClientModule],
  declarations: [
    AppComponent,
    StockTrackerComponent,
    StockListComponent,
    SentimentComponent,

    // directives
    PercentHighilightDirective,

    // pipes
    MonthStringPipe,
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}

import { Directive, HostBinding, Input } from '@angular/core';

@Directive({
  selector: '[appPercentHighlight]',
})
export class PercentHighilightDirective {
  lowColor: string = 'red';
  highColor: string = 'green';
  @Input() set appPercentHighlight(isHigh: boolean) {
    this.color = isHigh ? this.highColor : this.lowColor;
  }
  @HostBinding('style.color') color: string = '';
}

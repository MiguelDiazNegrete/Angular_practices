import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { StockTrackerComponent } from './stock-tracker/stock-tracker.component';
import { SentimentComponent } from './sentiment/sentiment.component';
import { StockListComponent } from './stock-tracker/stock-list/stock-list.component';

const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: '/stocks' },
  {
    path: 'stocks',
    component: StockTrackerComponent,
    children: [
      {
        path: '',
        component: StockListComponent,
      },
    ],
  },
  { path: 'sentiment/:symbol', component: SentimentComponent },
  // { path: '**', component: NotFoundComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}

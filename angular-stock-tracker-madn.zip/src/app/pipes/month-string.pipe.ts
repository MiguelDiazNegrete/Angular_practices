// Transforms month date from number to string, e.g: 1 to 'january'
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'monthString',
})
export class MonthStringPipe implements PipeTransform {
  transform(value: any): string {
    if (isNaN(value)) return value;

    const d = new Date();
    // since months on Date object starts from 0, we substract 1
    d.setMonth(value - 1);

    return d.toLocaleString('en-US', { month: 'long' });
  }
}
